import React, { useState, useEffect, useCallback } from 'react';
import { Plus, Search, ChevronDown, ChevronUp, Pencil, Trash2, X, Phone, IndianRupee, ChevronLeft, ChevronRight, Check } from 'lucide-react';

const FONT_IMPORT = `
@import url('https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,400;9..144,600;9..144,700&family=Noto+Sans+Devanagari:wght@400;500;600;700&family=Inter:wght@400;500;600;700&display=swap');
`;

const MONTHS = [
  { key: '01', hi: 'जन', en: 'Jan' }, { key: '02', hi: 'फर', en: 'Feb' },
  { key: '03', hi: 'मार्च', en: 'Mar' }, { key: '04', hi: 'अप्रैल', en: 'Apr' },
  { key: '05', hi: 'मई', en: 'May' }, { key: '06', hi: 'जून', en: 'Jun' },
  { key: '07', hi: 'जुल', en: 'Jul' }, { key: '08', hi: 'अग', en: 'Aug' },
  { key: '09', hi: 'सित', en: 'Sep' }, { key: '10', hi: 'अक्टू', en: 'Oct' },
  { key: '11', hi: 'नव', en: 'Nov' }, { key: '12', hi: 'दिस', en: 'Dec' },
];

function uid() {
  return Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
}

function currentYM() {
  const d = new Date();
  return { year: d.getFullYear(), month: String(d.getMonth() + 1).padStart(2, '0') };
}

export default function FeesLedger() {
  const [students, setStudents] = useState([]);
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState(false);
  const [search, setSearch] = useState('');
  const [expandedId, setExpandedId] = useState(null);
  const [viewYear, setViewYear] = useState(currentYM().year);
  const [modalOpen, setModalOpen] = useState(false);
  const [editingStudent, setEditingStudent] = useState(null);
  const [confirmDeleteId, setConfirmDeleteId] = useState(null);
  const [saving, setSaving] = useState(false);

  const { year: thisYear, month: thisMonth } = currentYM();

  // Load data
  useEffect(() => {
    (async () => {
      try {
        const res = await window.storage.get('students', false);
        if (res && res.value) {
          setStudents(JSON.parse(res.value));
        }
      } catch (e) {
        // key not found on first run is expected
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  const persist = useCallback(async (next) => {
    setSaving(true);
    try {
      await window.storage.set('students', JSON.stringify(next), false);
      setLoadError(false);
    } catch (e) {
      setLoadError(true);
    } finally {
      setSaving(false);
    }
  }, []);

  const updateStudents = (updater) => {
    setStudents((prev) => {
      const next = typeof updater === 'function' ? updater(prev) : updater;
      persist(next);
      return next;
    });
  };

  const togglePayment = (studentId, ymKey) => {
    updateStudents((prev) =>
      prev.map((s) =>
        s.id === studentId
          ? { ...s, payments: { ...s.payments, [ymKey]: !s.payments[ymKey] } }
          : s
      )
    );
  };

  const saveStudent = (data) => {
    if (data.id) {
      updateStudents((prev) => prev.map((s) => (s.id === data.id ? { ...s, ...data } : s)));
    } else {
      updateStudents((prev) => [...prev, { ...data, id: uid(), payments: {} }]);
    }
    setModalOpen(false);
    setEditingStudent(null);
  };

  const deleteStudent = (id) => {
    updateStudents((prev) => prev.filter((s) => s.id !== id));
    setConfirmDeleteId(null);
    if (expandedId === id) setExpandedId(null);
  };

  const filtered = students.filter((s) => {
    const q = search.trim().toLowerCase();
    if (!q) return true;
    return s.name.toLowerCase().includes(q) || (s.grade || '').toLowerCase().includes(q);
  });

  const thisMonthKey = `${thisYear}-${thisMonth}`;
  const collected = students.filter((s) => s.payments[thisMonthKey]).reduce((sum, s) => sum + Number(s.fee || 0), 0);
  const pending = students.filter((s) => !s.payments[thisMonthKey]).reduce((sum, s) => sum + Number(s.fee || 0), 0);
  const paidCount = students.filter((s) => s.payments[thisMonthKey]).length;

  return (
    <div style={{ minHeight: '100vh', background: '#F2EDDC', fontFamily: "'Inter', sans-serif" }}>
      <style>{FONT_IMPORT}{`
        .ledger-rule { background-image: repeating-linear-gradient(180deg, transparent, transparent 43px, #C9BFA0 44px); }
        .stamp-in { animation: stampIn 0.28s cubic-bezier(.2,1.4,.4,1); }
        @keyframes stampIn { 0% { transform: scale(1.6) rotate(-14deg); opacity: 0; } 100% { transform: scale(1) rotate(-8deg); opacity: 1; } }
        .fade-in { animation: fadeIn 0.18s ease-out; }
        @keyframes fadeIn { from { opacity: 0; transform: translateY(-4px); } to { opacity: 1; transform: translateY(0); } }
        input:focus, button:focus-visible { outline: 2px solid #1C2B4A; outline-offset: 1px; }
        @media (prefers-reduced-motion: reduce) { .stamp-in, .fade-in { animation: none; } }
      `}</style>

      {/* Header */}
      <div style={{ background: '#1C2B4A', position: 'relative', paddingBottom: 22 }}>
        <div style={{ position: 'absolute', left: 28, top: 0, bottom: 0, width: 2, background: 'repeating-linear-gradient(180deg, #A32B2B, #A32B2B 6px, transparent 6px, transparent 11px)' }} />
        <div style={{ padding: '22px 20px 14px 44px' }}>
          <div style={{ fontSize: 13, color: '#C9BFA0', letterSpacing: 0.5, marginBottom: 2 }}>
            Track every student's payments
          </div>
          <h1 style={{ fontFamily: "'Fraunces', serif", fontSize: 28, fontWeight: 700, color: '#F2EDDC', margin: 0 }}>
            Fees Ledger
          </h1>
        </div>

        {/* Summary strip */}
        <div style={{ display: 'flex', gap: 8, padding: '0 20px', marginLeft: 24 }}>
          <SummaryCard label="Total Students" value={students.length} />
          <SummaryCard label="Collected" value={`₹${collected.toLocaleString('en-IN')}`} accent="#2F6B4F" />
          <SummaryCard label="Pending" value={`₹${pending.toLocaleString('en-IN')}`} accent="#A32B2B" />
        </div>
      </div>

      {/* Search + Add */}
      <div style={{ padding: '16px 16px 8px', display: 'flex', gap: 8 }}>
        <div style={{ flex: 1, position: 'relative' }}>
          <Search size={16} color="#8A806A" style={{ position: 'absolute', left: 12, top: 12 }} />
          <input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search by name or class..."
            style={{
              width: '100%', boxSizing: 'border-box', padding: '10px 12px 10px 36px',
              borderRadius: 8, border: '1px solid #D9CFB0', background: '#FBF8EF',
              fontSize: 14, color: '#1C2B4A', fontFamily: "'Inter', sans-serif"
            }}
          />
        </div>
        <button
          onClick={() => { setEditingStudent(null); setModalOpen(true); }}
          style={{
            display: 'flex', alignItems: 'center', gap: 6, background: '#1C2B4A', color: '#F2EDDC',
            border: 'none', borderRadius: 8, padding: '0 16px', fontSize: 14, fontWeight: 600, cursor: 'pointer'
          }}
        >
          <Plus size={16} /> Add
        </button>
      </div>

      {loadError && (
        <div style={{ margin: '0 16px 8px', padding: '8px 12px', background: '#FBEAEA', color: '#A32B2B', fontSize: 13, borderRadius: 8 }}>
          Save failed. Please try again.
        </div>
      )}

      {/* Year switcher (for the expanded grid) */}
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 12, padding: '4px 0 12px', color: '#8A806A', fontSize: 13 }}>
        <button onClick={() => setViewYear((y) => y - 1)} style={iconBtnStyle}><ChevronLeft size={14} /></button>
        <span style={{ fontFamily: "'Fraunces', serif", fontWeight: 600, color: '#1C2B4A', fontSize: 15 }}>{viewYear}</span>
        <button onClick={() => setViewYear((y) => y + 1)} style={iconBtnStyle}><ChevronRight size={14} /></button>
      </div>

      {/* Student list */}
      <div style={{ padding: '0 16px 32px' }}>
        {loading ? (
          <div style={{ textAlign: 'center', color: '#8A806A', padding: 40, fontSize: 14 }}>Loading...</div>
        ) : filtered.length === 0 ? (
          <EmptyState hasStudents={students.length > 0} />
        ) : (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
            {filtered.map((s) => (
              <StudentRow
                key={s.id}
                student={s}
                isPaidThisMonth={!!s.payments[thisMonthKey]}
                expanded={expandedId === s.id}
                onToggleExpand={() => setExpandedId(expandedId === s.id ? null : s.id)}
                onTogglePay={() => togglePayment(s.id, thisMonthKey)}
                onToggleMonth={(mKey) => togglePayment(s.id, `${viewYear}-${mKey}`)}
                onEdit={() => { setEditingStudent(s); setModalOpen(true); }}
                onDeleteRequest={() => setConfirmDeleteId(s.id)}
                viewYear={viewYear}
                thisYear={thisYear}
                thisMonth={thisMonth}
              />
            ))}
          </div>
        )}
      </div>

      {saving && (
        <div style={{ position: 'fixed', bottom: 16, right: 16, background: '#1C2B4A', color: '#F2EDDC', fontSize: 12, padding: '6px 10px', borderRadius: 6, opacity: 0.85 }}>
          Saving...
        </div>
      )}

      {modalOpen && (
        <StudentModal
          student={editingStudent}
          onSave={saveStudent}
          onClose={() => { setModalOpen(false); setEditingStudent(null); }}
        />
      )}

      {confirmDeleteId && (
        <ConfirmDelete
          studentName={students.find((s) => s.id === confirmDeleteId)?.name}
          onCancel={() => setConfirmDeleteId(null)}
          onConfirm={() => deleteStudent(confirmDeleteId)}
        />
      )}
    </div>
  );
}

const iconBtnStyle = {
  border: '1px solid #D9CFB0', background: '#FBF8EF', borderRadius: 6, width: 26, height: 26,
  display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer', color: '#1C2B4A'
};

function SummaryCard({ label, value, accent }) {
  return (
    <div style={{
      flex: 1, background: '#F2EDDC', borderRadius: '10px 10px 0 0', padding: '10px 10px 12px',
      boxShadow: '0 -2px 0 rgba(0,0,0,0.04) inset'
    }}>
      <div style={{ fontFamily: "'Fraunces', serif", fontSize: 18, fontWeight: 700, color: accent || '#1C2B4A' }}>
        {value}
      </div>
      <div style={{ fontSize: 10.5, color: '#8A806A', marginTop: 2, lineHeight: 1.3 }}>{label}</div>
    </div>
  );
}

function EmptyState({ hasStudents }) {
  return (
    <div style={{ textAlign: 'center', padding: '48px 20px', color: '#8A806A' }}>
      <div style={{ fontFamily: "'Fraunces', serif", fontSize: 17, color: '#1C2B4A', marginBottom: 6 }}>
        {hasStudents ? 'No matches found' : 'No students yet'}
      </div>
      <div style={{ fontSize: 13 }}>
        {hasStudents ? 'Try a different search' : 'Tap "Add" to add your first student'}
      </div>
    </div>
  );
}

function StudentRow({ student, isPaidThisMonth, expanded, onToggleExpand, onTogglePay, onToggleMonth, onEdit, onDeleteRequest, viewYear, thisYear, thisMonth }) {
  return (
    <div style={{ background: '#FBF8EF', borderRadius: 12, border: '1px solid #E4DBC0', overflow: 'hidden' }}>
      <div style={{ display: 'flex', alignItems: 'center', padding: '12px 12px', gap: 10 }}>
        <div
          onClick={onToggleExpand}
          style={{ flex: 1, cursor: 'pointer', minWidth: 0 }}
        >
          <div style={{ fontSize: 15, fontWeight: 600, color: '#1C2B4A', whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
            {student.name}
          </div>
          <div style={{ fontSize: 12.5, color: '#8A806A', marginTop: 2, display: 'flex', gap: 8, alignItems: 'center' }}>
            {student.grade && <span>{student.grade}</span>}
            <span style={{ display: 'inline-flex', alignItems: 'center', gap: 2 }}>
              <IndianRupee size={11} />{Number(student.fee || 0).toLocaleString('en-IN')}/mo
            </span>
            {student.phone && <span style={{ display: 'inline-flex', alignItems: 'center', gap: 2 }}><Phone size={11} />{student.phone}</span>}
          </div>
        </div>

        <button
          onClick={onTogglePay}
          style={{
            border: 'none', borderRadius: 20, padding: '6px 12px', fontSize: 12.5, fontWeight: 700,
            cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 4,
            background: isPaidThisMonth ? '#E4F0E8' : '#FBEAEA',
            color: isPaidThisMonth ? '#2F6B4F' : '#A32B2B',
            transform: isPaidThisMonth ? 'rotate(-8deg)' : 'none'
          }}
          className={isPaidThisMonth ? 'stamp-in' : ''}
        >
          {isPaidThisMonth ? <><Check size={13} /> Paid</> : 'Pending'}
        </button>

        <button onClick={onToggleExpand} style={{ ...iconBtnStyle, border: 'none', background: 'transparent' }}>
          {expanded ? <ChevronUp size={16} /> : <ChevronDown size={16} />}
        </button>
      </div>

      {expanded && (
        <div className="fade-in" style={{ padding: '4px 12px 14px' }}>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 6, marginBottom: 10 }}>
            {MONTHS.map((m) => {
              const key = `${viewYear}-${m.key}`;
              const paid = !!student.payments[key];
              const isCurrent = viewYear === thisYear && m.key === thisMonth;
              return (
                <button
                  key={m.key}
                  onClick={() => onToggleMonth(m.key)}
                  style={{
                    border: isCurrent ? '1.5px solid #1C2B4A' : '1px solid #E4DBC0',
                    borderRadius: 8, padding: '7px 4px', fontSize: 11.5, fontWeight: 600, cursor: 'pointer',
                    background: paid ? '#E4F0E8' : '#F2EDDC',
                    color: paid ? '#2F6B4F' : '#8A806A'
                  }}
                >
                  {m.en}
                </button>
              );
            })}
          </div>
          <div style={{ display: 'flex', gap: 14, justifyContent: 'flex-end' }}>
            <button onClick={onEdit} style={{ display: 'flex', alignItems: 'center', gap: 4, background: 'none', border: 'none', color: '#1C2B4A', fontSize: 13, cursor: 'pointer' }}>
              <Pencil size={13} /> Edit
            </button>
            <button onClick={onDeleteRequest} style={{ display: 'flex', alignItems: 'center', gap: 4, background: 'none', border: 'none', color: '#A32B2B', fontSize: 13, cursor: 'pointer' }}>
              <Trash2 size={13} /> Delete
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

function StudentModal({ student, onSave, onClose }) {
  const [name, setName] = useState(student?.name || '');
  const [grade, setGrade] = useState(student?.grade || '');
  const [fee, setFee] = useState(student?.fee ?? '');
  const [phone, setPhone] = useState(student?.phone || '');
  const [error, setError] = useState('');

  const handleSave = () => {
    if (!name.trim()) { setError('Name is required'); return; }
    if (fee === '' || isNaN(Number(fee)) || Number(fee) < 0) { setError('Enter a valid fee amount'); return; }
    onSave({ id: student?.id, name: name.trim(), grade: grade.trim(), fee: Number(fee), phone: phone.trim() });
  };

  return (
    <div style={{ position: 'fixed', inset: 0, background: 'rgba(28,43,74,0.45)', display: 'flex', alignItems: 'flex-end', zIndex: 50 }} onClick={onClose}>
      <div
        className="fade-in"
        onClick={(e) => e.stopPropagation()}
        style={{ width: '100%', background: '#FBF8EF', borderRadius: '18px 18px 0 0', padding: 20, boxSizing: 'border-box' }}
      >
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 }}>
          <h2 style={{ fontFamily: "'Fraunces', serif", fontSize: 19, color: '#1C2B4A', margin: 0 }}>
            {student ? 'Edit Student' : 'Add New Student'}
          </h2>
          <button onClick={onClose} style={{ background: 'none', border: 'none', cursor: 'pointer', color: '#8A806A' }}><X size={20} /></button>
        </div>

        <Field label="Name">
          <input value={name} onChange={(e) => setName(e.target.value)} placeholder="e.g. Rahul Kumar" style={inputStyle} autoFocus />
        </Field>
        <Field label="Class">
          <input value={grade} onChange={(e) => setGrade(e.target.value)} placeholder="e.g. Class 2" style={inputStyle} />
        </Field>
        <Field label="Monthly Fee (₹)">
          <input value={fee} onChange={(e) => setFee(e.target.value)} placeholder="e.g. 500" inputMode="numeric" style={inputStyle} />
        </Field>
        <Field label="Phone (optional)">
          <input value={phone} onChange={(e) => setPhone(e.target.value)} placeholder="e.g. 98765xxxxx" inputMode="tel" style={inputStyle} />
        </Field>

        {error && <div style={{ color: '#A32B2B', fontSize: 13, marginBottom: 8 }}>{error}</div>}

        <button
          onClick={handleSave}
          style={{ width: '100%', background: '#1C2B4A', color: '#F2EDDC', border: 'none', borderRadius: 10, padding: '13px', fontSize: 15, fontWeight: 600, cursor: 'pointer', marginTop: 6 }}
        >
          Save
        </button>
      </div>
    </div>
  );
}

function Field({ label, children }) {
  return (
    <div style={{ marginBottom: 12 }}>
      <label style={{ display: 'block', fontSize: 12.5, color: '#8A806A', marginBottom: 5 }}>{label}</label>
      {children}
    </div>
  );
}

const inputStyle = {
  width: '100%', boxSizing: 'border-box', padding: '11px 12px', borderRadius: 9,
  border: '1px solid #D9CFB0', fontSize: 14.5, color: '#1C2B4A', background: '#FFFFFF',
  fontFamily: "'Inter', sans-serif"
};

function ConfirmDelete({ studentName, onCancel, onConfirm }) {
  return (
    <div style={{ position: 'fixed', inset: 0, background: 'rgba(28,43,74,0.45)', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 60, padding: 24 }} onClick={onCancel}>
      <div className="fade-in" onClick={(e) => e.stopPropagation()} style={{ background: '#FBF8EF', borderRadius: 14, padding: 20, maxWidth: 320 }}>
        <div style={{ fontFamily: "'Fraunces', serif", fontSize: 16, color: '#1C2B4A', marginBottom: 6 }}>
          Delete {studentName}?
        </div>
        <div style={{ fontSize: 13, color: '#8A806A', marginBottom: 16 }}>
          Their entire fee record will be deleted too. This cannot be undone.
        </div>
        <div style={{ display: 'flex', gap: 8, justifyContent: 'flex-end' }}>
          <button onClick={onCancel} style={{ padding: '8px 14px', borderRadius: 8, border: '1px solid #D9CFB0', background: 'transparent', color: '#1C2B4A', fontSize: 13.5, cursor: 'pointer' }}>
            Cancel
          </button>
          <button onClick={onConfirm} style={{ padding: '8px 14px', borderRadius: 8, border: 'none', background: '#A32B2B', color: '#FBF8EF', fontSize: 13.5, cursor: 'pointer', fontWeight: 600 }}>
            Delete
          </button>
        </div>
      </div>
    </div>
  );
}
