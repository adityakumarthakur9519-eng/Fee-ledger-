// Browser compatibility for the storage API used by the supplied component.
if (!window.storage) {
  window.storage = {
    async get(key) {
      const value = window.localStorage.getItem(key)
      return value === null ? null : { value }
    },
    async set(key, value) {
      window.localStorage.setItem(key, value)
      return true
    }
  }
}

import React from 'react'
import { createRoot } from 'react-dom/client'
import FeesLedger from '../fees-ledger.jsx'

createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <FeesLedger />
  </React.StrictMode>
)
