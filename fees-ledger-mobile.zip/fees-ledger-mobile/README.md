# Fees Ledger — Mobile Web App

This project wraps the supplied `fees-ledger.jsx` in a Vite React app and
provides a browser `window.storage` compatibility layer backed by localStorage.

## Run on a computer
1. Install Node.js (LTS).
2. Open a terminal in this folder.
3. Run:
   npm install
   npm run dev
4. Open the local URL shown by Vite.

## Put it on your Android phone
For a phone-accessible app, deploy this folder to a static host such as
Vercel, Netlify, or GitHub Pages, then open the deployed URL in Chrome and
choose "Add to Home screen".

Important: the current data storage is browser-local. Data saved on one
browser/device is not automatically shared with another device.
